**Policy Name** : deny\_when\_descriprion\_is\_short

**Policy Description** :This policy checks if the description provided is short or not.

**Date**: 21-3-2023

**Expiry Date** : 

**Owner** : TCS
