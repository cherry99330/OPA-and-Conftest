
**Policy Name** : deny\_when\_contact\_email\_not\_valid

**Policy Description** :
 This policy checks whether the given email is of the domain "gmail.com". 

**Date**: 17-3-2023

**Expiry Date** : 

**Owner** : TCS
