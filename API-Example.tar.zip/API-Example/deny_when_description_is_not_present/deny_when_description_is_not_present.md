**Policy Name** : deny\_when\_descriprion\_is\_not\_present

**Policy Description** :This policy checks if the parameter does not have the description attribute in it.

**Date**: 17-3-2023

**Expiry Date** : 

**Owner** : TCS
