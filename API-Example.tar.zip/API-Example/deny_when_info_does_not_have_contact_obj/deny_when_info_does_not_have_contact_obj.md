**Policy Name** : deny\_when\_info\_does\_not\_have\_contact\_obj

**Policy Description** :This policy checks if the info section contains contact object.

**Date**: 17-3-2023

**Expiry Date** : 

**Owner** : TCS
